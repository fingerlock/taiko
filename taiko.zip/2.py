import os 
import random 
import pygame 
import sys 

pygame.init() 

FPS = 50 
WIDTH = 1600
HEIGHT = 700
TILE_WIDTH = TILE_HEIGHT = 200
running = True
tiles_group = pygame.sprite.Group()
screen = pygame.display.set_mode((WIDTH, HEIGHT)) 
all_sprites = pygame.sprite.Group()
clock = pygame.time.Clock()
score = 0

def load_image(name, color_key=None): 
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
        image = image.convert_alpha()

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
            image.set_colorkey(color_key)
    return image


level_map = ['red', 'red', '_', 'red', 'blue', 'red', '_', 'red', 'red', 'blue', 'red', 'blue']



def generate_level(level):
    for x in range(len(level)):
         if __name__ == '__main__':
            if level[x] == 'red':
                Tile('red', x)
            elif level[x] == 'blue':
                Tile('blue', x)
            elif level[x] == '_':
                pass
tile_images = {
    'red': load_image('redhitcircle.png'),
    'blue': load_image('bluehitcircle.png')
}

class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x):
        super().__init__(tiles_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(TILE_WIDTH * pos_x + 1000, 500)
    def move(self):
        self.rect.x -= 6


class Blue(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        self.rect = self.image.get_rect()
        self.image = tile_images('blue')





class Red(pygame.sprite.Sprite):
    def __init__(self, group):
        super().__init__(group)
        self.rect = self.image.get_rect()
        self.image = tile_images('red')


class accuracy(pygame.sprite.Sprite):
    image = load_image('accuracychecker.png')
    def __init__(self, group):
        super().__init__(group)
        self.checker = accuracy.image
        self.rect = self.image.get_rect()
        self.rect.x = 50
        self.rect.y = 500
    def move(self):
        self.rect.x += 15

class hit(pygame.sprite.Sprite):
    image = load_image('hit300.png')
    def __init__(self, group):
        super().__init__(group)
        self.rect = self.image.get_rect()
        self.rect.x = 700
        self.rect.y = 350

class Drum:
    def __init__(self):
        self.dx = 0

    def apply(self, obj):
        obj.rect.x += self.dx

    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - WIDTH // 2)


print(tiles_group)
accuracycheck = accuracy(all_sprites)
generate_level(level_map)
drum = Drum()

while running:
    accuracycheck.move()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and (event.key == pygame.K_x or event.key == pygame.K_PERIOD)\
                and pygame.sprite.spritecollide(accuracycheck, tiles_group, False):
            score += 300
            hit300 = hit(all_sprites)
            print(score)
        elif event.type == pygame.KEYDOWN and (event.key == pygame.K_z or event.key == pygame.K_SLASH)\
                and pygame.sprite.spritecollide(accuracycheck, tiles_group, False):
            score += 300
            hit300 = hit(all_sprites)
            print(score)
    all_sprites.update()
    screen.fill(pygame.Color("white"))
    all_sprites.draw(screen)

    drum.update(accuracycheck)
    for sprite in all_sprites:
        drum.apply(sprite)

    pygame.display.flip()
    clock.tick(FPS)
pygame.quit()
print(score)